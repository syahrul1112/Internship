"# simpeg-Sistem-Infromasi-Kepegawaian-" 
(Aplikasi ini sudah tidak dilakukan maintenance. Sehingga kemungkinan masih terdapat bug di dalamnya. Hanya disarankan untuk referensi/pembelajaran).
1. import database pegawai.sql
2. konfigurasi application/config/database.php
3. buka http://localhost/simpeg-Sistem-Infromasi-Kepegawaian-
4. login =
   username: admin
   password: admin

5. Tampilan<br>
   data pegawai
   ![alt text](http://adlubgs.000webhostapp.com/storage/datapegawai.png)
    data kehadiran
   ![alt text](http://adlubgs.000webhostapp.com/storage/datakehadiran.png)
    absensi pegawai
   ![alt text](http://adlubgs.000webhostapp.com/storage/absensipegawai.png)
    Tunjangan Pendapatan Pegawai
   ![alt text](http://adlubgs.000webhostapp.com/storage/TPP.png)
    data user
   ![alt text](http://adlubgs.000webhostapp.com/storage/datauser.png)
