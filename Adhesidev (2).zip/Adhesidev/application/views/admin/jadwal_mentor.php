<?= $this->session->flashdata('pesan') ?>
 <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Mentor</th>
                  <th>Student</th>
                  <th>Jadwal</th>
                  <th>Course Taken</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                 <tbody>
                 <?php $no=1; foreach($data as $admin):
                $tgl=$admin['jam'];  
                ?>
                 <tr>
                 <td><?= $no ?></td>
                 <td> <?= $admin['nama_jabatan'] ?></td>
                 <td> <?= $admin['nama'] ?></td>
                 <td> <?= date("d-m-Y, h:i A", strtotime($tgl)) ?></td>
                 <td> <?= $admin['bidang'] ?></td>

                 <td><div id='isi4'><a href="<?= base_url('admin/jadwal_edit/'.$admin['id_jadwal']) ?>" class="btn btn-info">Edit</a> <a href="<?= base_url('admin/jadwal_hapus/'.$admin['id_jadwal']) ?>" class="btn btn-danger">Hapus</a></div></td> 
                 </tr>
                  <?php $no++; endforeach; ?>
                 </tbody>
              </table>
              <script>
